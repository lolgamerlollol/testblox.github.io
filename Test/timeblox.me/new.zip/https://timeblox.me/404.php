<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" id="www-roblox-com"><!-- MachineID: App1 --><head>
<link id="ctl00_Imports" rel="stylesheet" type="text/css" href="https://timeblox.me/AllCSS.css">
<link rel="icon" href="/favicon.ico">
<script src="https://code.jquery.com/jquery-3.1.0.min.js"></script
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="description" content="Timeblox">
<meta name="keywords" content="Old Roblox, Socialize, Games, old, blocks, building, finobe">
<meta name="author" content="Janx">
<title>Timeblox</title>

    </head>
<body>
<style type="text/css">
body {
  margin-top:0 !important;
  padding-top:0 !important;
  /*min-width:800px !important;*/
}
</style>
<!-- END WAYBACK TOOLBAR INSERT -->
    

    
    <div id="Container">
        
    

                <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><div id="Header">
            <div id="Banner">
                
                        

<div id="Options">
	<div id="Authentication"><span><a id="ctl00_BannerOptionsLoginView_BannerOptions_Anonymous_LoginHyperLink" href="https://timeblox.me/login.php">Login</a></span></div>
	<div id="Settings"></div>
</div>
                    
                <div id="Logo">
                    <a id="ctl00_rbxImage_Logo" title="Timeblox" href="https://timeblox.me" style="display:inline-block;cursor:pointer;"><img src="https://timeblox.me/roblox_logo.png" border="0" alt="Timeblox" blankurl="http://t6.roblox.com:80/blank-224x59.gif"></a>
                </div>
                
                        

<div id="Alerts"><table style="width:100%;height:100%">
        <tbody><tr>
            <td valign="middle"><a id="ctl00_BannerAlertsLoginView_BannerAlerts_Anonymous_rbxAlerts_SignupAndPlayHyperLink" class="SignUpAndPlay" text="Sign-up and Play!" href="https://timeblox.me/games.php" style="display:inline-block;cursor:pointer;"><img src="BannerPlay.png" border="0" blankurl="http://t1.roblox.com:80/blank-210x40.gif"></a>

</td>
        </tr>
    </tbody></table></div>
                    
            </div>
            

<div class="Navigation">
	<span><a id="ctl00_Menu_hlMyRoblox" class="MenuItem" href="https://timeblox.me/user.php">My Timeblox</a></span>
	<span class="Separator">&nbsp;|&nbsp;</span>
	<span><a id="ctl00_Menu_hlGames" class="MenuItem" href="https://timeblox.me/games.php">Games</a></span>
	<span class="Separator">&nbsp;|&nbsp;</span>
	<span><a id="ctl00_Menu_hlCatalog" class="MenuItem" href="https://timeblox.me/catalog.php">Catalog</a></span>
	<span class="Separator">&nbsp;|&nbsp;</span>
	<span><a id="ctl00_Menu_hlBrowse" class="MenuItem" href="https://timeblox.me/people.php">People</a></span>
	<span class="Separator">&nbsp;|&nbsp;</span>
	<span><a id="ctl00_Menu_hlForum" class="MenuItem" href="https://timeblox.me/forums/main.php">Forum</a></span>
	<span class="Separator">&nbsp;|&nbsp;</span>
	<span><a id="ctl00_Menu_hlForum" class="MenuItem" href="https://timeblox.me/blog/">News</a></span>
</div>
        </div>		<div id="Body"><center><h2>404</h2><br>
<img src="https://media.tenor.com/images/1bb43c99b5292235bf3b420b8bcb1bda/tenor.gif"></center>

        </div>
        

<div id="Footer">
	<iframe style="width:100%;height:1px;border:0;"></iframe>
    <hr>
    <p class="Legalese">
        Roblox, "Online Building Toy", characters, logos, names, and all related indicia are trademarks of Roblox, ©2008-2021.
        <br>Timeblox is not affiliated with Lego or Roblox. This is just a fan-made non-profit reimagination of a version of ROBLOX, most of us are more familiar to.
        <br>Use of this site signifies your acceptance of the <a id="ctl00_rbxFooter_hlTermsOfService" href="tos.php">Terms and Conditions</a>.
    </p>
</div>    </div>
    
    
</body></html>