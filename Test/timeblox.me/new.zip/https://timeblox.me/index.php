<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" id="www-roblox-com"><!-- MachineID: App1 --><head>
<link id="ctl00_Imports" rel="stylesheet" type="text/css" href="https://timeblox.me/AllCSS.css">
<link rel="icon" href="/favicon.ico">
<script src="https://code.jquery.com/jquery-3.1.0.min.js"></script
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="description" content="Timeblox">
<meta name="keywords" content="Old Roblox, Socialize, Games, old, blocks, building, finobe">
<meta name="author" content="Janx">
<title>Timeblox</title>

    </head>
<body>
<style type="text/css">
body {
  margin-top:0 !important;
  padding-top:0 !important;
  /*min-width:800px !important;*/
}
</style>
<!-- END WAYBACK TOOLBAR INSERT -->
    <form name="aspnetForm" method="post" action="Default.aspx" id="aspnetForm">

    
    <div id="Container">
        
    

                <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><div id="Header">
            <div id="Banner">
                
                        

<div id="Options">
	<div id="Authentication"><span><a id="ctl00_BannerOptionsLoginView_BannerOptions_Anonymous_LoginHyperLink" href="https://timeblox.me/login.php">Login</a></span></div>
	<div id="Settings"></div>
</div>
                    
                <div id="Logo">
                    <a id="ctl00_rbxImage_Logo" title="Timeblox" href="https://timeblox.me" style="display:inline-block;cursor:pointer;"><img src="https://timeblox.me/roblox_logo.png" border="0" alt="Timeblox" blankurl="http://t6.roblox.com:80/blank-224x59.gif"></a>
                </div>
                
                        

<div id="Alerts"><table style="width:100%;height:100%">
        <tbody><tr>
            <td valign="middle"><a id="ctl00_BannerAlertsLoginView_BannerAlerts_Anonymous_rbxAlerts_SignupAndPlayHyperLink" class="SignUpAndPlay" text="Sign-up and Play!" href="https://timeblox.me/games.php" style="display:inline-block;cursor:pointer;"><img src="BannerPlay.png" border="0" blankurl="http://t1.roblox.com:80/blank-210x40.gif"></a>

</td>
        </tr>
    </tbody></table></div>
                    
            </div>
            

<div class="Navigation">
	<span><a id="ctl00_Menu_hlMyRoblox" class="MenuItem" href="https://timeblox.me/user.php">My Timeblox</a></span>
	<span class="Separator">&nbsp;|&nbsp;</span>
	<span><a id="ctl00_Menu_hlGames" class="MenuItem" href="https://timeblox.me/games.php">Games</a></span>
	<span class="Separator">&nbsp;|&nbsp;</span>
	<span><a id="ctl00_Menu_hlCatalog" class="MenuItem" href="https://timeblox.me/catalog.php">Catalog</a></span>
	<span class="Separator">&nbsp;|&nbsp;</span>
	<span><a id="ctl00_Menu_hlBrowse" class="MenuItem" href="https://timeblox.me/people.php">People</a></span>
	<span class="Separator">&nbsp;|&nbsp;</span>
	<span><a id="ctl00_Menu_hlForum" class="MenuItem" href="https://timeblox.me/forums/main.php">Forum</a></span>
	<span class="Separator">&nbsp;|&nbsp;</span>
	<span><a id="ctl00_Menu_hlForum" class="MenuItem" href="https://timeblox.me/blog/">News</a></span>
</div>
        </div>        <div id="Body">
            
    
	<div id="SplashContainer">
		<div id="SignInPane">
			
<div id="LoginViewContainer">
	
			<div id="LoginView">
				<h5>Member Login</h5>
	<!---->			
	<script>
	$(document).ready(function() {
		$("#ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_Login").click(function() {
			if ($("#ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_Login").is(":disabled") == false) {
				$("#ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_Login").prop("disabled", true);
				var user = $("#ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_UserName").val(); 
				var passwd = $("#ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_Password").val(); 
				$.post('https://timeblox.me/zaloguj.php', {
					login: user,
					haslo: passwd
				})
				.done(function(response) {
					window.location.reload();
				})
				.fail(function() {
					
				});
			}
		});
	});
</script>
<div class="AspNet-Login">
						<div class="AspNet-Login">
							<div class="AspNet-Login-UserPanel">
								<label for="ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_UserName" id="ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_UserNameLabel" class="Label">Character Name</label>
								<input name="ctl00" type="text" id="ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_UserName" tabindex="1" class="Text">
							</div>
							<div class="AspNet-Login-PasswordPanel">
								<label for="ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_Password" id="ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_PasswordLabel" class="Label">Password</label>
								<input name="ctl00" type="password" id="ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_Password" tabindex="2" class="Text">
							</div>
							<!--div class="AspNet-Login-RememberMePanel"-->
								
							<!--/div-->
							<div class="AspNet-Login-SubmitPanel">
								<a id="ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_Login" tabindex="4" class="Button" href="javascript:__doPostBack('ctl00','')">Login</a>
							</div>
							
							<div id="ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_RegisterDiv" align="center">
								<br>
								<a id="ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_Register" tabindex="5" class="Button" href="https://timeblox.me/rejestracja.php">Register</a>
							</div>
							                         
							<div class="AspNet-Login-PasswordRecoveryPanel">
								<a id="ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_hlPasswordRecovery" tabindex="6" href="Login/ResetPasswordRequest.aspx">Forgot your password?</a>
							</div>
						</div>
					
</div><!---->
			</div>		
</div>

			<br>
            
				    <div id="Figure">
				        <a id="ctl00_cphRoblox_LoginView1_ImageFigure" disabled="disabled" title="Figure" onclick="return false" style="display:inline-block;"><img src="https://timeblox.me/NewFrontPageGuy.png" border="0" alt="Figure" blankurl="http://t1.roblox.com:80/blank-115x130.gif"></a>
				    </div>
			    
		</div>
		
		        

<div id="RobloxAtAGlance">
	<h2>Timeblox Virtual Playworld</h2>
	<h3>Timeblox is Free!</h3>
	<ul id="ThingsToDo">
		<li id="Point1">
			<h3>Build your personal Place</h3>
			<div>Create buildings, vehicles, scenery, and traps with thousands of virtual bricks.</div>
		</li>
		<li id="Point2">
			<h3>Meet new friends online</h3>
			<div>Visit your friend's place, chat in 3D, and build together.</div>
		</li>
		<li id="Point3">
			<h3>Battle in the Brick Arenas</h3>
			<div>Play with the slingshot, rocket, or other brick battle tools.  Be careful not to get "bloxxed".</div>
		</li>
	</ul>
	<div id="Showcase" onload="MM_CheckFlashVersion('8,0,0,0','Content on this page is awesome and requires a newer version of Macromedia Flash Player. Do you want to download it now?');">
        
        
<iframe id="embedplayer" src="https://www.bitview.net/embed.php?v=gVgKwTsrk1T" width="400" height="326" allowfullscreen scrolling="off" frameborder="0"></iframe>
    </div>
	<div id="Install">
		<div id="CompatibilityNote">Works with your<br>Windows PC!</div>
		<div id="DownloadAndPlay"><a id="ctl00_cphRoblox_RobloxAtAGlanceLoginView_RobloxAtAGlance_Anonymous_hlDownloadAndPlay" href="Login/New.aspx?ReturnUrl=%2fGames.aspx"><img src="https://timeblox.me/PlayNowGreenFader.gif" alt="FREE - Download and Play!" border="0"></a></div>
	</div>
	<div id="ForParents">
		<a id="ctl00_cphRoblox_RobloxAtAGlanceLoginView_RobloxAtAGlance_Anonymous_hlKidSafe" title="Timeblox is kid-safe!" href="Parents.aspx" style="display:inline-block;"><img title="Timeblox is kid-safe!" src="https://timeblox.me/COPPASeal-125x125.jpg" border="0"></a>
	</div>
</div>
		    
		


<div id="ctl00_cphRoblox_CoolPlaces_FlashContent">
<iframe src="about:blank" frameborder="0" height="1" width="900"></iframe></div> 
	</div>

        </div>
        

<div id="Footer">
	<iframe style="width:100%;height:1px;border:0;"></iframe>
    <hr>
    <p class="Legalese">
        Roblox, "Online Building Toy", characters, logos, names, and all related indicia are trademarks of Roblox, ©2008-2021.
        <br>Timeblox is not affiliated with Lego or Roblox. This is just a fan-made non-profit reimagination of a version of ROBLOX, most of us are more familiar to.
        <br>Use of this site signifies your acceptance of the <a id="ctl00_rbxFooter_hlTermsOfService" href="tos.php">Terms and Conditions</a>.
    </p>
</div>    </div>
    
    
</body></html>