<form action="zaloguj.php" method="post">
	
		Character Name: <br /> <input type="text" name="login" /> <br />
		Password: <br /> <input type="password" name="haslo" /> <br /><br />
		<input type="submit" value="Login" />
	
	</form>
	<form action="rejestracja.php" method="get">
		<input type="submit" value="Register" />
	</form>
	