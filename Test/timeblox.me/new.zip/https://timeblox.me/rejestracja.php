<head><script src="https://hcaptcha.com/1/api.js" async defer></script><link id="ctl00_Imports" rel="stylesheet" type="text/css" href="https://timeblox.me/AllCSS.css">
<link rel="icon" href="/favicon.ico">
<script src="https://code.jquery.com/jquery-3.1.0.min.js"></script
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="description" content="Timeblox">
<meta name="keywords" content="Old Roblox, Socialize, Games, old, blocks, building, finobe">
<meta name="author" content="Janx">
<title>Timeblox</title></head>
<div id="Container">
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><div id="Header">
            <div id="Banner">
                
                        

<div id="Options">
	<div id="Authentication"><span><a id="ctl00_BannerOptionsLoginView_BannerOptions_Anonymous_LoginHyperLink" href="https://timeblox.me/login.php">Login</a></span></div>
	<div id="Settings"></div>
</div>
                    
                <div id="Logo">
                    <a id="ctl00_rbxImage_Logo" title="Timeblox" href="https://timeblox.me" style="display:inline-block;cursor:pointer;"><img src="https://timeblox.me/roblox_logo.png" border="0" alt="Timeblox" blankurl="http://t6.roblox.com:80/blank-224x59.gif"></a>
                </div>
                
                        

<div id="Alerts"><table style="width:100%;height:100%">
        <tbody><tr>
            <td valign="middle"><a id="ctl00_BannerAlertsLoginView_BannerAlerts_Anonymous_rbxAlerts_SignupAndPlayHyperLink" class="SignUpAndPlay" text="Sign-up and Play!" href="https://timeblox.me/games.php" style="display:inline-block;cursor:pointer;"><img src="BannerPlay.png" border="0" blankurl="http://t1.roblox.com:80/blank-210x40.gif"></a>

</td>
        </tr>
    </tbody></table></div>
                    
            </div>
            

<div class="Navigation">
	<span><a id="ctl00_Menu_hlMyRoblox" class="MenuItem" href="https://timeblox.me/user.php">My Timeblox</a></span>
	<span class="Separator">&nbsp;|&nbsp;</span>
	<span><a id="ctl00_Menu_hlGames" class="MenuItem" href="https://timeblox.me/games.php">Games</a></span>
	<span class="Separator">&nbsp;|&nbsp;</span>
	<span><a id="ctl00_Menu_hlCatalog" class="MenuItem" href="https://timeblox.me/catalog.php">Catalog</a></span>
	<span class="Separator">&nbsp;|&nbsp;</span>
	<span><a id="ctl00_Menu_hlBrowse" class="MenuItem" href="https://timeblox.me/people.php">People</a></span>
	<span class="Separator">&nbsp;|&nbsp;</span>
	<span><a id="ctl00_Menu_hlForum" class="MenuItem" href="https://timeblox.me/forums/main.php">Forum</a></span>
	<span class="Separator">&nbsp;|&nbsp;</span>
	<span><a id="ctl00_Menu_hlForum" class="MenuItem" href="https://timeblox.me/blog/">News</a></span>
</div>
        </div><div id="Body">
            
    
	<div id="Registration">
			<form action="regform.php" method="post">
			<div id="ctl00_cphTIMEBLOX_upAccountRegistration">

					<h2>Sign Up and Play</h2>
					<h3>Step 1 of 2: Create Account</h3>
					<div id="EnterUsername">
						<fieldset title="Choose a name for your TIMEBLOX character">
							<legend>Choose a name for your TIMEBLOX character</legend>
							<div class="Suggestion">
								Use 3-20 alphanumeric characters: A-Z, a-z, 0-9, no spaces
							</div>
							<div class="Validators">
								<div></div>
								<div></div>
								<div></div>
								<div></div>
								<div></div>
							</div>
							<div class="UsernameRow">
								<label for="ctl00_cphTIMEBLOX_UserName" id="ctl00_cphTIMEBLOX_UserNameLabel" class="Label">Character Name:</label>&nbsp;<input type="text" name="user" class="TextBox"/>
							</div>
						</fieldset>
					</div>
					<div id="EnterPassword">
						<fieldset title="Choose your TIMEBLOX password">
							<legend>Choose your TIMEBLOX password</legend>
							<div class="Suggestion">
								4-10 characters, no spaces
							</div>
							<div class="Validators">
								<div></div>
								<div></div>
								<div></div>
								<div></div>
							</div>
							<div class="PasswordRow">
								<label for="ctl00_cphTIMEBLOX_Password" id="ctl00_cphTIMEBLOX_LabelPassword" class="Label">Password:</label>&nbsp;<input type="password" name="pass" class="TextBox"/>
							</div>
							<div class="ConfirmPasswordRow">
								<label for="ctl00_cphTIMEBLOX_TextBoxPasswordConfirm" id="ctl00_cphTIMEBLOX_LabelPasswordConfirm" class="Label">Confirm Password:</label>&nbsp;<input type="password" name="cpass" class="TextBox"/>
							</div>
						</fieldset>
					</div>
					<style>
					    #Registration #EnterUsername, #Registration #EnterEmail, #Registration #EnterAgeGroup, #Registration #EnterChatMode {
    margin: 0 auto;
    width: 60%;
}
					</style>
										
					</div>
					<div id="EnterEmail">
						<fieldset title="Provide your email address">
							<legend>Provide your email address</legend>
							<div class="Suggestion">
								We need to verify you.
							</div>
							<div class="Validators">
								<div></div>
								<div></div>
							</div>
							<div class="EmailRow">
								<label for="ctl00_cphTIMEBLOX_TextBoxEMail" id="ctl00_cphTIMEBLOX_LabelEmail" class="Label">Your Email:</label>&nbsp;<input type="email" name="email" class="TextBox"/>
							</div>
						</fieldset>
					</div>
					<div id="EnterEmail">
						<fieldset title="Provide your email address" style="height: 105px;">
							<legend>Solve the CAPTCHA</legend>
							<div class="Suggestion">We need you to complete the CAPTCHA to prevent spam.</div>
							<div class="Validators">
								<div></div>
								<div></div>
							</div>
							<div class="EmailRow">
								<div class="h-captcha" data-sitekey="4103d053-ef02-46a2-8d42-f278b17c4c8c"></div>
								<br/><p>&nbsp;</p>
							</div>
						</fieldset>
					</div>
					<center></center>
					<div class="Confirm">
						<input href="#" type="submit" name="sign_up" value="Register" id="fuckcaaa" class="BigButton">
					</div>
</form>
</div><div id="Sidebars">
			<div id="AlreadyRegistered">
				<h3>Already Registered?</h3>
				<p>If you just need to login, go to the <a id="ctl00_cphTIMEBLOX_HyperLinkLogin" href="/Login">Login</a> page.</p>
				</div>
      <div id="TermsAndConditions">
      				<h3>Terms &amp; Conditions</h3>
      				<p>Registration does not provide any guarantees of service. See our <a id="ctl00_cphTIMEBLOX_HyperLinkToS" href="#" target="_blank">Terms of Service</a> and <a id="ctl00_cphTIMEBLOX_HyperLinkEULA" href="#" target="_blank">Licensing Agreement</a> for details.</p>
      				<p>TIMEBLOX will not share your email address with 3rd parties. See our <a id="ctl00_cphTIMEBLOX_HyperLinkPrivacy" href="#" target="_blank">Privacy Policy</a> for details.</p>
      			</div>
		</div>

        </div>
<div id="Footer">
	<iframe style="width:100%;height:1px;border:0;"></iframe>
    <hr>
    <p class="Legalese">
        Roblox, "Online Building Toy", characters, logos, names, and all related indicia are trademarks of Roblox, ©2008-2021.
        <br>Timeblox is not affiliated with Lego or Roblox. This is just a fan-made non-profit reimagination of a version of ROBLOX, most of us are more familiar to.
        <br>Use of this site signifies your acceptance of the <a id="ctl00_rbxFooter_hlTermsOfService" href="tos.php">Terms and Conditions</a>.
    </p>
</div>		</div>
<!--<form action="regform.php" method="post">
		epiculy is a pussy (confirmed)<br/>
		Username:<input type="text" name="user" /> <br />
		E-Mail:<input type="email" name="email" class="TextBox"/> <br />
		Password:<input type="password" name="pass" class="TextBox"/> <br />
		Confirm Password:<input type="password" name="cpass" class="TextBox"/> <br />
		<div class="h-captcha" data-sitekey="4103d053-ef02-46a2-8d42-f278b17c4c8c"></div>

		<input type="submit" value="Submit" />
	
</form>-->